from pathlib import Path

from classifier import classify_coding_intent
from router import CosBrain


def brain(tmp_path: Path) -> CosBrain:
    return CosBrain(sandbox_root=tmp_path / "sandboxes")


def test_debug_traceback_is_handled_by_cos(tmp_path):
    b = brain(tmp_path)
    msg = (
        "Debug this. TypeError / NameError on my function.\n"
        "```python\n"
        "def add(a, b):\n"
        "    return a + c\n"
        "```"
    )
    result = b.receive(msg, session_id="g1", face="concierge")
    assert result.is_coding
    assert result.handled_by == "cos-builder"
    assert "app.py" in result.files_changed
    assert result.commands[-1]["exit_code"] == 0
    assert "5" in (result.commands[-1]["stdout"] or "")


def test_write_and_run_script(tmp_path):
    b = brain(tmp_path)
    result = b.receive(
        "Write a small Python script that prints a checklist and run it.",
        session_id="g2",
        face="cos",
    )
    assert result.handled_by == "cos-builder"
    assert result.commands[0]["exit_code"] == 0
    assert "ship classifier" in result.commands[0]["stdout"]


def test_portable_html(tmp_path):
    b = brain(tmp_path)
    result = b.receive(
        "Make a simple portable HTML page I can download.",
        session_id="g3",
        face="concierge",
    )
    assert result.handled_by == "cos-builder"
    assert "index.html" in result.files_changed
    assert "<!DOCTYPE html>" in result.files["index.html"]


def test_self_modify_refused(tmp_path):
    b = brain(tmp_path)
    result = b.receive(
        "Rewrite COS and change Concierge internals and the promotion pipeline.",
        session_id="g4",
        face="concierge",
    )
    assert result.refused_self_modify
    assert "cannot modify COS" in result.output


def test_non_coding_stays_on_normal_path(tmp_path):
    b = brain(tmp_path)
    result = b.receive(
        "What time is the next train to the airport?",
        session_id="g5",
        face="concierge",
    )
    assert result.handled_by == "concierge-normal"
    assert result.is_coding is False


def test_classifier_fenced_code():
    intent = classify_coding_intent("please look at this:\n```python\nprint(1)\n```")
    assert intent.is_coding


def test_ingests_attachment_into_sandbox(tmp_path):
    src = tmp_path / "broken.py"
    src.write_text("def add(a, b):\n    return a + c\n", encoding="utf-8")
    b = brain(tmp_path)
    result = b.receive(
        "Debug this attachment, I get NameError.",
        session_id="g6",
        face="concierge",
        attachments=[str(src)],
    )
    assert result.handled_by == "cos-builder"
    listed = (tmp_path / "sandboxes" / "g6" / "broken.py").read_text(encoding="utf-8")
    assert "return a + c" in listed
